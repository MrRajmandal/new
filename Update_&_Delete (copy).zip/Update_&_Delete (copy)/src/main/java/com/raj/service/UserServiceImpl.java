package com.raj.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.raj.dao.UserDao;
import com.raj.model.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userDao;
	
	@Override
	public void add(User user) {
		userDao.save(user);
	}

	@Override
	public List<User> getAll() {
		return (List<User>) userDao.findAll();
	}
	
	@Override 
	public User removeById(int id) {
		User user = userDao.findById(id).orElse(null);
		if (user != null) {
			userDao.deleteById(id);
		}
		return user;
	}
	@Override
	public void update(User user) {
		userDao.save(user);
	}
	
}
