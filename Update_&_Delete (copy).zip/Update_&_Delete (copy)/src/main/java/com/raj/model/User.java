package com.raj.model;

import java.util.List;

import org.hibernate.annotations.DialectOverride.GeneratedColumn;
import org.hibernate.annotations.DialectOverride.GeneratedColumns;

import jakarta.persistence.Column;

@jakarta.persistence.Entity
public class User {
	@jakarta.persistence.Id
	@jakarta.persistence.GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
	private int id;
	@Column
	private String name;
	@Column
	private String Address;
	@Column
	private String State;
	@Column
	private String City;
	
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static List<User> ArrayList() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
