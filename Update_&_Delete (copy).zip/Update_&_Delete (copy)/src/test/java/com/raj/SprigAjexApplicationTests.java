package com.raj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprigAjexApplicationTests {

	@Test
	void contextLoads() {
	}

}
