package jaspers;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.itextpdf.text.log.Logger;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import java.sql.Connection;
import net.sf.jasperreports.engine.util.JRStyledTextParser;

public class ReportDto {
    public List<PurchaseOrderData> fetchDataFromDatabase(int piId) {
        List<PurchaseOrderData> dataList = new ArrayList<PurchaseOrderData>();
 
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demodb", "root", "Rajmandal");
            String query1="select * from YourTableName";
             PreparedStatement preparedStatement = connection.prepareStatement(query1);
      //    preparedStatement.setInt(1, piId);
            ResultSet resultSet = preparedStatement.executeQuery();     
            while (resultSet.next()) {
            PurchaseOrderData data = new PurchaseOrderData();
           data.setSignup_id(resultSet.getInt("signup_id")) ;     //same name as table column name
           data.setPi_id(resultSet.getInt("pi_id"));
            data.setExporter_detail(resultSet.getString("exporter_detail"));
           data.setExporter_address(resultSet.getString("exporter_address"));   
            dataList.add(data);              
            }        
            resultSet.close();         
            preparedStatement.close();          
          // connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dataList;
    }
  public JasperPrint generateAndExportReport(int piId ) {
    try {
    	 
 
         String filePath ="/home/raj/Documents/Projects/freelancing/jspdemo5/src/main/webapp/pdftable3modification_A5.jrxml";
         List<PurchaseOrderData> dataList = fetchDataFromDatabase(piId);
         File file = new File(filePath);
        if(file.exists() && file.isFile()){
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(dataList);
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("CollectionBeanParam", dataSource);
        FileInputStream input = new FileInputStream(file);                  
        JasperDesign jasperDesign = JRXmlLoader.load(input);
        JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);       
        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport,parameters,new JREmptyDataSource()); 
        String outputFilePath = "/home/raj/Documents/Projects/freelancing/jspdemo5"+ File.separator + "JasperReport1.pdf";
        JasperExportManager.exportReportToPdfFile(jasperPrint, outputFilePath);
       	 
          JasperViewer.viewReport(jasperPrint,false);      
            
 
        // Provide a download link to the user
        System.out.println("Download Link: file://" + outputFilePath);        
   
        }
    }catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
  public void calls() {
	    
	    int piId =123; // Set the PI ID here
	    generateAndExportReport(piId);
	     
	}

}