package jaspers;


public class PurchaseOrderData {
    private int signup_id;
    private int pi_id;
    private String exporter_detail;
    private String exporter_address;
	/**
	 * @return the signup_id
	 */
	public int getSignup_id() {
		return signup_id;
	}
	/**
	 * @param signup_id the signup_id to set
	 */
	public void setSignup_id(int signup_id) {
		this.signup_id = signup_id;
	}
	/**
	 * @return the pi_id
	 */
	public int getPi_id() {
		return pi_id;
	}
	/**
	 * @param pi_id the pi_id to set
	 */
	public void setPi_id(int pi_id) {
		this.pi_id = pi_id;
	}
	/**
	 * @return the exporter_detail
	 */
	public String getExporter_detail() {
		return exporter_detail;
	}
	/**
	 * @param exporter_detail the exporter_detail to set
	 */
	public void setExporter_detail(String exporter_detail) {
		this.exporter_detail = exporter_detail;
	}
	/**
	 * @return the exporter_address
	 */
	public String getExporter_address() {
		return exporter_address;
	}
	/**
	 * @param exporter_address the exporter_address to set
	 */
	public void setExporter_address(String exporter_address) {
		this.exporter_address = exporter_address;
	}
    
    
    
}